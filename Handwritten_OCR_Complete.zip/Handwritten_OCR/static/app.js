let stream = null;
let capturedDataUrl = null;
let lastResult = null;
let activeKeyword = "";

const $ = (id) => document.getElementById(id);

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2600);
}

async function startCamera() {
  try {
    if (stream) stopCamera();
    const facingMode = $("cameraFacing").value;
    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: facingMode }, width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: false
    });
    $("video").srcObject = stream;
    $("cameraPlaceholder").style.display = "none";
    await $("video").play();
    toast("Camera đã được bật.");
  } catch (err) {
    toast("Không mở được camera. Hãy kiểm tra quyền truy cập và HTTPS.");
  }
}

function stopCamera() {
  if (stream) stream.getTracks().forEach(track => track.stop());
  stream = null;
  $("video").srcObject = null;
  $("cameraPlaceholder").style.display = "flex";
}

function captureImage() {
  const video = $("video");
  if (!video.videoWidth) return toast("Hãy mở camera trước.");
  const canvas = document.createElement("canvas");
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext("2d").drawImage(video, 0, 0);
  setImage(canvas.toDataURL("image/jpeg", 0.92));
  toast("Đã chụp ảnh.");
}

function setImage(dataUrl) {
  capturedDataUrl = dataUrl;
  lastResult = null;
  activeKeyword = "";
  $("previewPlaceholder").style.display = "none";
  $("resultCanvas").style.display = "block";
  $("recognizedText").value = "";
  $("detectionRows").innerHTML = '<tr><td colspan="7" class="empty-cell">Ảnh đã sẵn sàng. Nhấn Bắt đầu nhận dạng.</td></tr>';
  $("totalCount").textContent = "0";
  $("matchCount").textContent = "0";
  $("avgConfidence").textContent = "—";
  $("imageSize").textContent = "—";
  $("searchSummary").textContent = "Chưa thực hiện tìm kiếm.";
  drawCanvas();
}

$("startCamera").addEventListener("click", startCamera);
$("stopCamera").addEventListener("click", stopCamera);
$("capture").addEventListener("click", captureImage);

$("fileInput").addEventListener("change", async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  if (!file.type.startsWith("image/")) return toast("Vui lòng chọn tệp hình ảnh.");
  if (file.size > 12 * 1024 * 1024) return toast("Ảnh tối đa 12 MB.");
  const reader = new FileReader();
  reader.onload = () => {
    setImage(reader.result);
    toast("Đã tải ảnh lên.");
  };
  reader.readAsDataURL(file);
});

async function recognize() {
  if (!capturedDataUrl) return toast("Hãy chụp ảnh hoặc tải ảnh lên trước.");
  $("recognize").disabled = true;
  $("recognize").textContent = "Đang nhận dạng...";
  try {
    const response = await fetch("/api/recognize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        image: capturedDataUrl,
        preprocess: $("preprocess").value
      })
    });
    const data = await response.json();
    if (!response.ok || !data.success) throw new Error(data.error || "OCR thất bại.");
    lastResult = data;
    activeKeyword = "";
    $("recognizedText").value = data.full_text;
    updateMetrics(data);
    renderTable(data.detections);
    $("searchSummary").textContent = `Đã phát hiện ${data.total} vùng chữ. Nhập từ khóa để tìm kiếm.`;
    drawCanvas();
    toast("Nhận dạng hoàn tất.");
  } catch (err) {
    toast("Lỗi: " + err.message);
  } finally {
    $("recognize").disabled = false;
    $("recognize").textContent = "✦ Bắt đầu nhận dạng";
  }
}
$("recognize").addEventListener("click", recognize);

function updateMetrics(data) {
  const avg = data.detections.length
    ? data.detections.reduce((sum, d) => sum + d.confidence, 0) / data.detections.length
    : 0;
  $("totalCount").textContent = data.total;
  $("matchCount").textContent = "0";
  $("avgConfidence").textContent = data.total ? avg.toFixed(1) + "%" : "—";
  $("imageSize").textContent = `${data.image_width} × ${data.image_height}`;
}

function renderTable(items) {
  const tbody = $("detectionRows");
  if (!items.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-cell">Không phát hiện được vùng chữ trong ảnh.</td></tr>';
    return;
  }
  tbody.innerHTML = items.map(d => `
    <tr>
      <td>${d.id}</td><td>${escapeHtml(d.text)}</td><td>${d.x}</td><td>${d.y}</td>
      <td>${d.width}</td><td>${d.height}</td><td>${d.confidence.toFixed(2)}%</td>
    </tr>`).join("");
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  })[ch]);
}

function drawCanvas() {
  if (!capturedDataUrl) return;
  const canvas = $("resultCanvas");
  const ctx = canvas.getContext("2d");
  const img = new Image();
  img.onload = () => {
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    ctx.drawImage(img, 0, 0);
    if (!lastResult) return;

    lastResult.detections.forEach(d => {
      const matched = activeKeyword &&
        d.text.toLocaleLowerCase("vi").includes(activeKeyword.toLocaleLowerCase("vi"));
      if (activeKeyword && !matched) return;

      ctx.beginPath();
      ctx.moveTo(d.box[0][0], d.box[0][1]);
      d.box.slice(1).forEach(p => ctx.lineTo(p[0], p[1]));
      ctx.closePath();
      ctx.lineWidth = Math.max(2, img.naturalWidth / 500);
      ctx.strokeStyle = matched ? "#ef3038" : "#14a66b";
      ctx.stroke();

      const label = String(d.id);
      ctx.font = `bold ${Math.max(14, img.naturalWidth / 65)}px Arial`;
      const labelWidth = ctx.measureText(label).width + 10;
      const lx = d.x;
      const ly = Math.max(0, d.y - 25);
      ctx.fillStyle = matched ? "#ef3038" : "#1768d2";
      ctx.fillRect(lx, ly, labelWidth, 23);
      ctx.fillStyle = "#fff";
      ctx.fillText(label, lx + 5, ly + 17);
    });
  };
  img.src = capturedDataUrl;
}

function searchKeyword() {
  if (!lastResult) return toast("Hãy nhận dạng ảnh trước khi tìm kiếm.");
  const keyword = $("keyword").value.trim();
  if (!keyword) {
    activeKeyword = "";
    $("matchCount").textContent = "0";
    $("searchSummary").textContent = "Đã xóa bộ lọc tìm kiếm.";
    renderTable(lastResult.detections);
    drawCanvas();
    return;
  }
  activeKeyword = keyword;
  const matches = lastResult.detections.filter(d =>
    d.text.toLocaleLowerCase("vi").includes(keyword.toLocaleLowerCase("vi"))
  );
  $("matchCount").textContent = matches.length;
  $("searchSummary").textContent = matches.length
    ? `Tìm thấy ${matches.length} vùng chứa từ khóa “${keyword}”. Các vùng phù hợp được đánh dấu màu đỏ.`
    : `Không tìm thấy từ khóa “${keyword}”.`;
  renderTable(matches);
  drawCanvas();
}
$("searchBtn").addEventListener("click", searchKeyword);
$("keyword").addEventListener("keydown", e => { if (e.key === "Enter") searchKeyword(); });

$("copyText").addEventListener("click", async () => {
  const text = $("recognizedText").value;
  if (!text) return toast("Chưa có văn bản để sao chép.");
  try {
    await navigator.clipboard.writeText(text);
    toast("Đã sao chép văn bản.");
  } catch {
    $("recognizedText").select();
    document.execCommand("copy");
    toast("Đã sao chép văn bản.");
  }
});

async function downloadExport(endpoint, payload) {
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error || "Không thể xuất tệp.");
  }
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = endpoint.endsWith("txt") ? "ket_qua_nhan_dang.txt" : "ket_qua_nhan_dang.json";
  a.click();
  URL.revokeObjectURL(url);
}
$("downloadTxt").addEventListener("click", async () => {
  try {
    if (!lastResult) return toast("Chưa có kết quả OCR.");
    await downloadExport("/api/export/txt", { text: $("recognizedText").value });
  } catch (e) { toast(e.message); }
});
$("downloadJson").addEventListener("click", async () => {
  try {
    if (!lastResult) return toast("Chưa có kết quả OCR.");
    await downloadExport("/api/export/json", lastResult);
  } catch (e) { toast(e.message); }
});

window.addEventListener("beforeunload", stopCamera);
